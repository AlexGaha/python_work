from flask_app import app , render_template
from flask_app.models.user import User

@app.route('/dojos')
def form():
    return render_template("create.html")

